package com.example.obrasacessiveis

import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.yourapp.ObraAdapterAdmin
import com.example.yourapp.ObraViewModel

class ListActivityAdmin : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ObraAdapterAdmin
    private val obraViewModel: ObraViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        val backButton: ImageButton = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            finish() // Finaliza a atividade e volta para a tela anterior
        }

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        obraViewModel.getObras().observe(this, Observer { obras ->
            if (obras != null) {
                adapter = ObraAdapterAdmin(this, obras)
                recyclerView.adapter = adapter
            }
        })
    }
}



