package com.example.yourapp

import com.example.obrasacessiveis.Obra

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.toObject

class ObraViewModel : ViewModel() {

    private val obrasLiveData = MutableLiveData<List<Obra>>()

    fun getObras(): LiveData<List<Obra>> {
        if (obrasLiveData.value == null) {
            loadObras()
        }
        return obrasLiveData
    }

    private fun loadObras() {
        val db = FirebaseFirestore.getInstance()
        db.collection("Obras")
            .get()
            .addOnSuccessListener { querySnapshot ->
                val obras = querySnapshot.documents.mapNotNull { it.toObject<Obra>() }
                obrasLiveData.value = obras
            }
            .addOnFailureListener { e ->
                // Handle the error if necessary
            }
    }
}


