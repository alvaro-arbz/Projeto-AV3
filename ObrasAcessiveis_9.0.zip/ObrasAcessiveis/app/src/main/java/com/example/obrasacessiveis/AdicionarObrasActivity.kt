package com.example.obrasacessiveis

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID

class AdicionarObrasActivity : Activity() {
    private var imageUri: Uri? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adicionar_obra)

        val ok = findViewById<ImageButton>(R.id.checkButton)
        val cancel = findViewById<ImageButton>(R.id.cancelButton)
        val titulo = findViewById<EditText>(R.id.titleTextView)
        val descricao = findViewById<EditText>(R.id.textEditText)
        val ano = findViewById<EditText>(R.id.authorEditText)
        val autor = findViewById<EditText>(R.id.yearEditText)
        val imagem = findViewById<ImageView>(R.id.imageView)

        // Obter a URI da imagem do Intent
        val imageUriString = intent.getStringExtra("IMAGE_URI")
        imageUriString?.let {
            imageUri = Uri.parse(it)
            Glide.with(this)
                .load(imageUri)
                .into(imagem)
        }

        ok.setOnClickListener {
            if (titulo.text.isEmpty() || descricao.text.isEmpty() || ano.text.isEmpty() || autor.text.isEmpty()) {
                Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Gerar um ID único para a obra (usado como ID do QR code e do documento Firestore)
            val obraId = UUID.randomUUID().toString()

            // Upload da imagem para o Firebase Storage
            imageUri?.let { uri ->
                val storageRef = FirebaseStorage.getInstance().reference
                val fileRef = storageRef.child("Obras/$obraId.jpg")
                fileRef.putFile(uri)
                    .addOnSuccessListener {
                        fileRef.downloadUrl.addOnSuccessListener { downloadUrl ->
                            // Salvar dados da obra no Firestore com a URL da imagem e o ID
                            salvarObraNoFirestore(
                                obraId,
                                titulo.text.toString(),
                                descricao.text.toString(),
                                autor.text.toString(),
                                ano.text.toString(),
                                downloadUrl.toString()
                            )
                        }
                    }
                    .addOnFailureListener { exception ->
                        Log.e("FirebaseStorage", "Erro ao fazer upload da imagem", exception)
                        Toast.makeText(this, "Erro ao salvar imagem", Toast.LENGTH_SHORT).show()
                    }
            } ?: run {
                Toast.makeText(this, "Nenhuma imagem selecionada", Toast.LENGTH_SHORT).show()
            }
        }

        cancel.setOnClickListener {
            VoltarParaEscanearObra()
        }
    }

    private fun salvarObraNoFirestore(obraId: String, titulo: String, descricao: String, autor: String, ano: String, imageUrl: String) {
        val db = FirebaseFirestore.getInstance()
        val obra = mapOf(
            "id" to obraId, // Salvando o ID do documento
            "titulo" to titulo,
            "descricao" to descricao,
            "autor" to autor,
            "ano" to ano,
            "imageUrl" to imageUrl
        )
        db.collection("Obras").document(obraId).set(obra)
            .addOnSuccessListener {
                Log.d("FirebaseFirestore", "Obra adicionada com sucesso")
                TrocarParaObraCadastrada(obraId)
            }
            .addOnFailureListener { exception ->
                Log.e("FirebaseFirestore", "Erro ao adicionar obra", exception)
                Toast.makeText(this, "Erro ao salvar obra", Toast.LENGTH_SHORT).show()
            }
    }

    private fun TrocarParaObraCadastrada(documentId: String) {
        val telaAdicionar = Intent(this, ObraCadastradaActivity::class.java).apply {
            putExtra("DOCUMENT_ID", documentId)
        }
        startActivity(telaAdicionar)
    }

    private fun VoltarParaEscanearObra() {
        val intent = Intent(this, EscanearObrasAdminActivity::class.java)
        startActivity(intent)
    }
}
