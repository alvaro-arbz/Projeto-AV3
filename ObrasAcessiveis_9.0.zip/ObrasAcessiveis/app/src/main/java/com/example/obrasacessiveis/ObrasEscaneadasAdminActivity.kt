package com.example.obrasacessiveis

import TranslationService
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

class ObrasEscaneadasAdminActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var tituloTextView: TextView
    private lateinit var descricaoTextView: TextView
    private lateinit var autorTextView: TextView
    private lateinit var anoTextView: TextView
    private lateinit var obraImageView: ImageView
    private lateinit var translationService: TranslationService
    private lateinit var textToSpeech: TextToSpeech
    private lateinit var labelDescricao: TextView
    private lateinit var labelAutor: TextView
    private lateinit var labelAno: TextView

    private var isPortuguese: Boolean = true // Estado atual do idioma

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_obras_escaneadas_admin)

        val editButton = findViewById<ImageButton>(R.id.editButton)
        val voltarButton = findViewById<ImageButton>(R.id.voltarButton)
        val translateButton = findViewById<ImageButton>(R.id.translateButton)
        val micButton = findViewById<ImageButton>(R.id.scanButton)
        tituloTextView = findViewById(R.id.titleTextView)
        descricaoTextView = findViewById(R.id.descriptionEditText)
        autorTextView = findViewById(R.id.authorEditText)
        anoTextView = findViewById(R.id.yearEditText)
        obraImageView = findViewById(R.id.obraImageView)

        labelDescricao = findViewById(R.id.descriptionLabel)
        labelAutor = findViewById(R.id.authorLabel)
        labelAno = findViewById(R.id.yearLabel)


        // Recebendo dados do Intent
        val titulo = intent.getStringExtra("titulo")
        val descricao = intent.getStringExtra("descricao")
        val autor = intent.getStringExtra("autor")
        val ano = intent.getStringExtra("ano")
        val imageUrl = intent.getStringExtra("imageUrl")
        val obraId = intent.getStringExtra("id")

        // Log para verificar o ID recebido
        Log.d("ObrasEscaneadasAdmin", "Recebido obraId: $obraId")

        tituloTextView.text = titulo
        descricaoTextView.text = descricao
        autorTextView.text = autor
        anoTextView.text = ano

        if (!imageUrl.isNullOrEmpty()) {
            Glide.with(this)
                .load(imageUrl)
                .into(obraImageView)
        }

        textToSpeech = TextToSpeech(this, this)

        voltarButton.setOnClickListener {
            finish()
        }

        editButton.setOnClickListener {
            Log.d("ObrasEscaneadasAdmin", "Chamando TrocarParaAtualizarObra")
            TrocarParaAtualizarObra(titulo, descricao, autor, ano, imageUrl, obraId)
        }

        translateButton.setOnClickListener {
            alternarIdiomaTTS()
        }

        micButton.setOnClickListener {
            falarTextoDaTela()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            setLanguage(Locale("pt", "BR"))
        } else {
            // Lidar com a inicialização falhada do TTS
        }
    }

    private fun setLanguage(locale: Locale) {
        val result = textToSpeech.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Lidar com o erro caso o idioma não seja suportado
        }
    }

    @SuppressLint("SetTextI18n")
    private fun alternarIdiomaTTS() {
        isPortuguese = !isPortuguese
        if (isPortuguese) {
            labelDescricao.text = "Descrição"
            labelAutor.text = "Autor"
            labelAno.text = "Ano"
            setLanguage(Locale("pt", "BR"))
        } else {
            labelDescricao.text = "Description"
            labelAutor.text = "Author"
            labelAno.text = "Year"
            setLanguage(Locale("en", "US"))
        }
    }



    private fun falarTextoDaTela() {
        val texto = if (isPortuguese) {
            """
                Título: ${tituloTextView.text}
                Descrição: ${descricaoTextView.text}
                Autor: ${autorTextView.text}
                Ano: ${anoTextView.text}
            """.trimIndent()
        } else {
            """
                Title: ${tituloTextView.text}
                Description: ${descricaoTextView.text}
                Author: ${autorTextView.text}
                Year: ${anoTextView.text}
            """.trimIndent()
        }
        textToSpeech.speak(texto, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    override fun onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop()
            textToSpeech.shutdown()
        }
        super.onDestroy()
    }

    private fun TrocarParaAtualizarObra(titulo: String?, descricao: String?, autor: String?, ano: String?, imageUrl: String?, obraId: String?) {
        val intent = Intent(this, AtualizarObrasActivity::class.java).apply {
            putExtra("titulo", titulo)
            putExtra("descricao", descricao)
            putExtra("autor", autor)
            putExtra("ano", ano)
            putExtra("imageUrl", imageUrl)
            putExtra("id", obraId)
        }
        startActivityForResult(intent, REQUEST_CODE_UPDATE_OBRA)
    }

    private suspend fun translateText(text: String, targetLanguage: String): String {
        return withContext(Dispatchers.IO) {
            val response = translationService.translate(text, "auto", targetLanguage).execute()
            if (response.isSuccessful) {
                response.body()?.translatedText ?: text
            } else {
                text
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_UPDATE_OBRA && resultCode == Activity.RESULT_OK) {
            data?.let {
                val titulo = it.getStringExtra("titulo")
                val descricao = it.getStringExtra("descricao")
                val autor = it.getStringExtra("autor")
                val ano = it.getStringExtra("ano")
                val imageUrl = it.getStringExtra("imageUrl")

                tituloTextView.text = titulo
                descricaoTextView.text = descricao
                autorTextView.text = autor
                anoTextView.text = ano

                if (!imageUrl.isNullOrEmpty()) {
                    Glide.with(this)
                        .load(imageUrl)
                        .into(obraImageView)
                }
            }
        }
    }

    companion object {
        const val REQUEST_CODE_UPDATE_OBRA = 1
    }
}
