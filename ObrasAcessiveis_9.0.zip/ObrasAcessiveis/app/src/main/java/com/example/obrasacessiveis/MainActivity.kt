package com.example.obrasacessiveis

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MainActivity : Activity() {

    private lateinit var campoEmail: EditText
    private lateinit var campoSenha: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val view = View(this)
        setContentView(R.layout.activity_login)

        val button = findViewById<Button>(R.id.loginButton)
        val souUsuario = findViewById<TextView>(R.id.souUsuario)
        val cadastrese = findViewById<TextView>(R.id.criarcadastro)

        campoEmail = findViewById(R.id.emailEditText)
        campoSenha = findViewById(R.id.passwordEditText)

        button.setOnClickListener() {
            buscarObraPorTitulo(campoEmail.text.toString())
        }
        cadastrese.setOnClickListener() {
            FazerCadastro()
        }
        souUsuario.setOnClickListener() {
            TrocarDeTela2()
        }

    }
    private fun TrocarDeTela() {
        val outraTela = Intent(this, EscanearObrasAdminActivity::class.java)
        startActivity(outraTela)
    }
    private fun TrocarDeTela2() {
        val outraTela = Intent(this, EscanearObrasUsuarioActivity::class.java)
        startActivity(outraTela)
    }
    private fun FazerCadastro() {
        val outraTela = Intent(this, FazerCadastroActivity::class.java)
        startActivity(outraTela)
    }

    fun buscarObraPorTitulo(emailBuscado: String) {
        var email: String = ""
        var senha: String = ""
        val db = FirebaseFirestore.getInstance()
        db.collection("Cadastro")
            .whereEqualTo("email", emailBuscado)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    Toast.makeText(this, "Email ou senha incorretos", Toast.LENGTH_SHORT).show()
                } else {
                    for (document in documents) {
                        email = document.getString("email") ?: "Email não encontrado"
                        senha = document.getString("senha") ?: "Senha não encontrada"


                        if(email.isEmpty()) {
                            Toast.makeText(this, "Email ou senha incorretos", Toast.LENGTH_SHORT).show()
                        }

                        Log.d("Buscar", "Cadastro encontrada - Email: $email, Senha: $senha")
                    }
                    if(email == campoEmail.text.toString() && senha == campoSenha.text.toString()) {
                        val outraTela = Intent(this, EscanearObrasUsuarioActivity::class.java)
                        startActivity(outraTela)
                    } else {
                        Toast.makeText(this, "Email ou senha incorretos", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .addOnFailureListener { exception ->
                Log.w("Buscar", "Erro ao buscar documentos: ", exception)
            }
    }
}