package com.example.obrasacessiveis

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.io.OutputStream

class ObraCadastradaActivity : Activity() {
    private lateinit var qrCodeBitmap: Bitmap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_obra_cadastrada)

        val qrCodeImageView = findViewById<ImageView>(R.id.qrCodeImageView)
        val ok = findViewById<ImageButton>(R.id.checkButton)
        val download = findViewById<ImageButton>(R.id.downloadButton)

        // Obter o ID do documento do Intent
        val documentId = intent.getStringExtra("DOCUMENT_ID")
        documentId?.let {
            qrCodeBitmap = generateQRCode(it)
            qrCodeImageView.setImageBitmap(qrCodeBitmap)
        }

        ok.setOnClickListener {
            TrocarParaEscanearObra()
        }

        download.setOnClickListener {
            saveImageToGallery(qrCodeBitmap)
        }
    }

    private fun TrocarParaEscanearObra() {
        val outraTela = Intent(this, EscanearObrasAdminActivity::class.java)
        startActivity(outraTela)
    }

    private fun generateQRCode(text: String): Bitmap {
        val size = 512 // pixels
        val qrCodeWriter = QRCodeWriter()
        val bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, size, size)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) {
            for (y in 0 until size) {
                bitmap.setPixel(x, y, if (bitMatrix.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }
        return bitmap
    }

    private fun saveImageToGallery(bitmap: Bitmap) {
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "QRCode_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/QR Codes")
        }

        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
        if (uri != null) {
            var outputStream: OutputStream? = null
            try {
                outputStream = contentResolver.openOutputStream(uri)
                if (outputStream != null) {
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                    Toast.makeText(this, "QR Code salvo na galeria", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Erro ao salvar QR Code", Toast.LENGTH_SHORT).show()
            } finally {
                outputStream?.close()
            }
        } else {
            Toast.makeText(this, "Erro ao salvar QR Code", Toast.LENGTH_SHORT).show()
        }
    }
}
