package com.example.yourapp

import com.example.obrasacessiveis.Obra
import com.example.obrasacessiveis.ObrasEscaneadasAdminActivity
import com.example.obrasacessiveis.R
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ObraAdapterAdmin(private val context: Context, private val obras: List<Obra>) :
    RecyclerView.Adapter<ObraAdapterAdmin.ObraViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ObraViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_obra, parent, false)
        return ObraViewHolder(view)
    }

    override fun onBindViewHolder(holder: ObraViewHolder, position: Int) {
        val obra = obras[position]
        holder.bind(obra)
        holder.itemView.setOnClickListener {
            val intent = Intent(context, ObrasEscaneadasAdminActivity::class.java).apply {
                putExtra("titulo", obra.titulo)
                putExtra("descricao", obra.descricao)
                putExtra("autor", obra.autor)
                putExtra("ano", obra.ano)
                putExtra("imageUrl", obra.imageUrl)
                putExtra("id", obra.id)
            }
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = obras.size

    inner class ObraViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val obraImage: ImageView = itemView.findViewById(R.id.obraImage)
        private val obraTitle: TextView = itemView.findViewById(R.id.obraTitle)
        private val obraAuthor: TextView = itemView.findViewById(R.id.obraAuthor)
        private val obraYear: TextView = itemView.findViewById(R.id.obraYear)
        private val obraDescription: TextView = itemView.findViewById(R.id.obraDescription)

        fun bind(obra: Obra) {
            obraTitle.text = obra.titulo
            obraAuthor.text = obra.autor
            obraYear.text = obra.ano
            obraDescription.text = obra.descricao
            Glide.with(context).load(obra.imageUrl).into(obraImage)
        }
    }
}

