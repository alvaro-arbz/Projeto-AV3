package com.example.obrasacessiveis

import TranslationService
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale


class ObrasEscaneadasUsuarioActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var obraImageView: ImageView
    private lateinit var textToSpeech: TextToSpeech
    private var isPortuguese: Boolean = true // Estado atual do idioma
    private lateinit var tituloTextView: TextView
    private lateinit var descricaoTextView: TextView
    private lateinit var autorTextView: TextView
    private lateinit var anoTextView: TextView
    private lateinit var translationService: TranslationService
    private lateinit var labelDescricao: TextView
    private lateinit var labelAutor: TextView
    private lateinit var labelAno: TextView


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_obras_escaneadas_usuario)
        val voltar = findViewById<ImageButton>(R.id.voltarButton)

        val micButton = findViewById<ImageButton>(R.id.scanButton)
        val translateButton = findViewById<ImageButton>(R.id.translateButton)
        obraImageView = findViewById(R.id.obraImageView)

        labelDescricao = findViewById(R.id.descriptionLabel)
        labelAutor = findViewById(R.id.authorLabel)
        labelAno = findViewById(R.id.yearLabel)

        tituloTextView = findViewById(R.id.titleTextView)
        descricaoTextView = findViewById(R.id.descriptionEditText)
        autorTextView = findViewById(R.id.authorEditText)
        anoTextView = findViewById(R.id.yearEditText)
        obraImageView = findViewById(R.id.obraImageView)

        val tituloBuscado = intent.getStringExtra("titulo")
        val descricaoBuscada = intent.getStringExtra("descricao")
        val autorBuscado = intent.getStringExtra("autor")
        val anoBuscado = intent.getStringExtra("ano")
        val imageUrl = intent.getStringExtra("imageUrl")
        val obraId = intent.getStringExtra("id")

        tituloTextView.text = tituloBuscado
        descricaoTextView.text = descricaoBuscada
        autorTextView.text = autorBuscado
        anoTextView.text = anoBuscado

        textToSpeech = TextToSpeech(this, this)


        if (!imageUrl.isNullOrEmpty()) {
            Glide.with(this)
                .load(imageUrl)
                .into(obraImageView)
        }

        voltar.setOnClickListener() {
            finish()
        }

        micButton.setOnClickListener() {
            falarTextoDaTela()
        }

        translateButton.setOnClickListener() {
            alternarIdiomaTTS()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            setLanguage(Locale("pt", "BR"))
        } else {
            // Lidar com a inicialização falhada do TTS
        }
    }

    private fun setLanguage(locale: Locale) {
        val result = textToSpeech.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Lidar com o erro caso o idioma não seja suportado
        }
    }

    @SuppressLint("SetTextI18n")
    private fun alternarIdiomaTTS() {
        isPortuguese = !isPortuguese
        if (isPortuguese) {
            labelDescricao.text = "Descrição"
            labelAutor.text = "Autor"
            labelAno.text = "Ano"
            setLanguage(Locale("pt", "BR"))
        } else {
            labelDescricao.text = "Description"
            labelAutor.text = "Author"
            labelAno.text = "Year"
            setLanguage(Locale("en", "US"))
        }
    }

    private suspend fun translateText(text: String, targetLanguage: String): String {
        return withContext(Dispatchers.IO) {
            val response = translationService.translate(text, "auto", targetLanguage).execute()
            if (response.isSuccessful) {
                response.body()?.translatedText ?: text
            } else {
                text
            }
        }
    }

    private fun falarTextoDaTela() {
        val texto = if (isPortuguese) {
            """
                Título: ${tituloTextView.text}
                Descrição: ${descricaoTextView.text}
                Autor: ${autorTextView.text}
                Ano: ${anoTextView.text}
            """.trimIndent()
        } else {
            """
                Title: ${tituloTextView.text}
                Description: ${descricaoTextView.text}
                Author: ${autorTextView.text}
                Year: ${anoTextView.text}
            """.trimIndent()
        }
        textToSpeech.speak(texto, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    override fun onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop()
            textToSpeech.shutdown()
        }
        super.onDestroy()
    }

    private fun VoltarParaEscanearObra() {
        val telaAdicionar = Intent(this, EscanearObrasUsuarioActivity::class.java)
        startActivity(telaAdicionar)
    }
}

