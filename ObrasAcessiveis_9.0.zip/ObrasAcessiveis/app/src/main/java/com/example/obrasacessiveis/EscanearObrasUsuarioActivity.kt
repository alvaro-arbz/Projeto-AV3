package com.example.obrasacessiveis

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.google.firebase.firestore.FirebaseFirestore
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult

class EscanearObrasUsuarioActivity : Activity() {
    private var uriImagem: Uri? = null
    private val PICK_IMAGE_REQUEST = 0
    private var qrCodeResult: String = ""
    private lateinit var imageView: ImageView
    private lateinit var labelPesquisar: TextView
    private lateinit var labelScan: TextView

    private var isPortuguese: Boolean = true // Estado atual do idioma

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_escanear_obras_usuario)

        imageView = findViewById(R.id.imageView)
        val listButton = findViewById<ImageButton>(R.id.listButton)
        val checkButton = findViewById<ImageButton>(R.id.checkButton)
        val titulo = findViewById<EditText>(R.id.searchEditText)
        val escanear = findViewById<ImageButton>(R.id.scanButton)
        val translateButton = findViewById<ImageButton>(R.id.translateButton)


        labelPesquisar = findViewById(R.id.searchLabel)
        labelScan = findViewById(R.id.scanLabel)

        checkButton.setOnClickListener() {
            buscarObraPorTitulo(titulo.text.toString())
        }
        escanear.setOnClickListener() {
            escanearQrCode()
        }

        listButton.setOnClickListener {
            val intent = Intent(this, ListActivityUsuario::class.java)
            startActivity(intent)
        }

        translateButton.setOnClickListener() {
            alternarIdiomaTTS()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun alternarIdiomaTTS() {
        isPortuguese = !isPortuguese
        if (isPortuguese) {
            labelPesquisar.text = "Pesquisar obra"
            labelScan.text = "Escanear obra"
        } else {
            labelPesquisar.text = "Search artwork"
            labelScan.text = "Scan artwork"
        }
    }

    fun escanearQrCode() {
        val scanner = IntentIntegrator(this)
        scanner.setBeepEnabled(false)
        scanner.setOrientationLocked(true)
        scanner.setCaptureActivity(CaptureActivityPortrait::class.java)
        scanner.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
        scanner.initiateScan()
    }

    private fun buscarObraPorTitulo(tituloBuscado: String) {
        val db = FirebaseFirestore.getInstance()
        db.collection("Obras")
            .whereEqualTo("titulo", tituloBuscado)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    Log.d("Buscar", "Nenhum documento encontrado com o título: $tituloBuscado")
                    Toast.makeText(this, "Obra não encontrada", Toast.LENGTH_SHORT).show()
                } else {
                    for (document in documents) {
                        val titulo = document.getString("titulo") ?: "Título não encontrado"
                        val descricao = document.getString("descricao") ?: "Descrição não encontrada"
                        val autor = document.getString("autor") ?: "Autor não encontrado"
                        val ano = document.getString("ano") ?: "Ano não encontrado"
                        val imageUrl = document.getString("imageUrl") ?: ""
                        val id = document.getString("id") ?: "Id não encontrado"

                        val intent = Intent(this, ObrasEscaneadasUsuarioActivity::class.java).apply {
                            putExtra("titulo", titulo)
                            putExtra("descricao", descricao)
                            putExtra("autor", autor)
                            putExtra("ano", ano)
                            putExtra("imageUrl", imageUrl)
                            putExtra("id", id)
                        }
                        startActivity(intent)
                    }
                }
            }
            .addOnFailureListener { exception ->
                Log.w("Buscar", "Erro ao buscar documentos: ", exception)
                Toast.makeText(this, "Erro ao buscar documentos", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                PICK_IMAGE_REQUEST -> {
                    if (data != null) {
                        uriImagem = data.data

                        Glide.with(this)
                            .asBitmap()
                            .load(uriImagem)
                            .listener(object : RequestListener<Bitmap> {
                                override fun onLoadFailed(
                                    e: GlideException?,
                                    model: Any?,
                                    target: Target<Bitmap>?,
                                    isFirstResource: Boolean
                                ): Boolean {
                                    Toast.makeText(
                                        applicationContext,
                                        "Falha ao selecionar imagem",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    return false
                                }

                                override fun onResourceReady(
                                    resource: Bitmap?,
                                    model: Any?,
                                    target: Target<Bitmap>?,
                                    dataSource: com.bumptech.glide.load.DataSource?,
                                    isFirstResource: Boolean
                                ): Boolean {
                                    // Imagem carregada com sucesso
                                    return false
                                }
                            })
                            .into(imageView)
                    } else {
                        Toast.makeText(applicationContext, "Falha ao selecionar imagem", Toast.LENGTH_LONG).show()
                    }
                }
                else -> {
                    val result: IntentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
                    if (result != null) {
                        if (result.contents == null) {
                            Toast.makeText(this, "Cancelado", Toast.LENGTH_LONG).show()
                        } else {
                            qrCodeResult = result.contents
                            buscarObraPorId(qrCodeResult)
                        }
                    }
                }
            }
        }
    }

    private fun buscarObraPorId(id: String) {
        val db = FirebaseFirestore.getInstance()
        db.collection("Obras").document(id).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val titulo = document.getString("titulo") ?: "Título não encontrado"
                    val descricao = document.getString("descricao") ?: "Descrição não encontrada"
                    val autor = document.getString("autor") ?: "Autor não encontrado"
                    val ano = document.getString("ano") ?: "Ano não encontrado"
                    val imageUrl = document.getString("imageUrl") ?: ""

                    val intent = Intent(this, ObrasEscaneadasUsuarioActivity::class.java).apply {
                        putExtra("titulo", titulo)
                        putExtra("descricao", descricao)
                        putExtra("autor", autor)
                        putExtra("ano", ano)
                        putExtra("imageUrl", imageUrl)
                    }
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Obra não encontrada", Toast.LENGTH_LONG).show()
                }
            }
            .addOnFailureListener { exception ->
                Log.w("Buscar", "Erro ao buscar documentos: ", exception)
                Toast.makeText(this, "Erro ao buscar documentos", Toast.LENGTH_LONG).show()
            }
    }
}
