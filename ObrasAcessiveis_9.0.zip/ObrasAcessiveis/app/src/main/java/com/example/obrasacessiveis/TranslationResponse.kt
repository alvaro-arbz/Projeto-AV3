package com.example.obrasacessiveis

data class TranslationResponse(val translatedText: String)


