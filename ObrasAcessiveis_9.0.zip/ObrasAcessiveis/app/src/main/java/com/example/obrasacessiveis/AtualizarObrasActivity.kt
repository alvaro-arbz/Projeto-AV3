package com.example.obrasacessiveis

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore

class AtualizarObrasActivity : Activity() {

    private lateinit var tituloEditText: EditText
    private lateinit var descricaoEditText: EditText
    private lateinit var autorEditText: EditText
    private lateinit var anoEditText: EditText
    private lateinit var obraImageView: ImageView
    private var obraId: String? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_atualizar_obra)

        tituloEditText = findViewById(R.id.titleTextView)
        descricaoEditText = findViewById(R.id.textEditText)
        autorEditText = findViewById(R.id.authorEditText)
        anoEditText = findViewById(R.id.yearEditText)
        obraImageView = findViewById(R.id.obraImageView)

        // Recebendo dados do Intent
        val titulo = intent.getStringExtra("titulo")
        val descricao = intent.getStringExtra("descricao")
        val autor = intent.getStringExtra("autor")
        val ano = intent.getStringExtra("ano")
        val imageUrl = intent.getStringExtra("imageUrl")
        obraId = intent.getStringExtra("id") // Recebe o ID da obra

        // Log para verificar o ID
        Log.d("AtualizarObra", "Recebido obraId: $obraId")

        // Preenchendo os campos com os dados recebidos
        tituloEditText.setText(titulo)
        descricaoEditText.setText(descricao)
        autorEditText.setText(autor)
        anoEditText.setText(ano)

        if (!imageUrl.isNullOrEmpty()) {
            Glide.with(this)
                .load(imageUrl)
                .into(obraImageView)
        }

        findViewById<ImageButton>(R.id.checkButton).setOnClickListener {
            atualizarObra()
        }

        findViewById<ImageButton>(R.id.deleteButton).setOnClickListener {
            deletarObra()
        }

        findViewById<ImageButton>(R.id.voltarButton).setOnClickListener {
            VoltarParaEscanearObra()
        }
    }

    private fun atualizarObra() {
        val db = FirebaseFirestore.getInstance()
        val obraAtualizada = mapOf(
            "titulo" to tituloEditText.text.toString(),
            "descricao" to descricaoEditText.text.toString(),
            "autor" to autorEditText.text.toString(),
            "ano" to anoEditText.text.toString()
        )

        obraId?.let {
            db.collection("Obras").document(it).update(obraAtualizada)
                .addOnSuccessListener {
                    Log.d("AtualizarObra", "Obra atualizada com sucesso")
                    val intent = Intent().apply {
                        putExtra("titulo", tituloEditText.text.toString())
                        putExtra("descricao", descricaoEditText.text.toString())
                        putExtra("autor", autorEditText.text.toString())
                        putExtra("ano", anoEditText.text.toString())
                        putExtra("imageUrl", intent.getStringExtra("imageUrl"))
                    }
                    setResult(Activity.RESULT_OK, intent)
                    finish()
                }
                .addOnFailureListener { e ->
                    Log.e("AtualizarObra", "Erro ao atualizar a obra", e)
                    Toast.makeText(this, "Erro ao atualizar a obra", Toast.LENGTH_SHORT).show()
                }
        } ?: run {
            Log.e("AtualizarObra", "Erro: ID da obra é nulo")
            Toast.makeText(this, "Erro ao atualizar a obra: ID da obra é nulo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deletarObra() {
        val db = FirebaseFirestore.getInstance()

        obraId?.let {
            db.collection("Obras").document(it).delete()
                .addOnSuccessListener {
                    Log.d("DeletarObra", "Obra deletada com sucesso")
                    Toast.makeText(this, "Obra deletada com sucesso", Toast.LENGTH_SHORT).show()
                    val telaAdicionar = Intent(this, EscanearObrasAdminActivity::class.java)
                    startActivity(telaAdicionar)

                }
                .addOnFailureListener { e ->
                    Log.e("DeletarObra", "Erro ao deletar a obra", e)
                    Toast.makeText(this, "Erro ao deletar a obra", Toast.LENGTH_SHORT).show()
                }
        } ?: run {
            Log.e("DeletarObra", "Erro: ID da obra é nulo")
            Toast.makeText(this, "Erro ao deletar a obra: ID da obra é nulo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun VoltarParaEscanearObra() {
        val intent = Intent().apply {
            putExtra("titulo", tituloEditText.text.toString())
            putExtra("descricao", descricaoEditText.text.toString())
            putExtra("autor", autorEditText.text.toString())
            putExtra("ano", anoEditText.text.toString())
            putExtra("imageUrl", intent.getStringExtra("imageUrl"))
        }
        setResult(Activity.RESULT_OK, intent)
        finish()
    }
}
