package com.example.obrasacessiveis

data class Obra(
    val titulo: String = "",
    val autor: String = "",
    val ano: String = "",
    val descricao: String = "",
    val imageUrl: String = "",
    val id: String = ""

)
